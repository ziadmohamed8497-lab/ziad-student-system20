#!/usr/bin/env python3
"""Generates the static HTML site (run from the project root:  python3 _tools/build.py).
The generated .html files are the deliverable; this script is only a convenience for regenerating them."""
import json, os, html as H

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = json.load(open(os.path.join(ROOT, "_tools", "data.json"), encoding="utf-8"))
EN, AR = D["en"], D["ar"]
SERVICES, CONCEPTS = D["SERVICES"], D["CONCEPTS"]
SITE_URL = ""   # e.g. "https://www.example.com" — when set, sitemap.xml is generated

BUDGETS = [("lt_5k", "Under 5,000 EGP", "أقل من 5,000 جنيه"), ("5k_15k", "5,000–15,000 EGP", "من 5,000 إلى 15,000 جنيه"), ("15k_35k", "15,000–35,000 EGP", "من 15,000 إلى 35,000 جنيه"),
           ("35k_75k", "35,000–75,000 EGP", "من 35,000 إلى 75,000 جنيه"), ("gt_75k", "Above 75,000 EGP", "أكثر من 75,000 جنيه"), ("undecided", "Not decided", "لم أحدد بعد")]
SERVICE_CODES = ["website", "web_app", "management_system", "educational", "ecommerce", "dashboard_crm", "ui_ux", "ai", "automation", "maintenance", "other"]
TIMELINES = ["asap", "1_month", "1_3_months", "3_6_months", "flexible"]
ARROW = '<svg class="arrow" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M1 8h13M9 3l5 5-5 5" stroke="currentColor" stroke-width="1.4"/></svg>'
e = H.escape

def B(en, ar, tag="span"):
    return f'<{tag} class="en" lang="en">{e(en)}</{tag}><{tag} class="ar" lang="ar">{e(ar)}</{tag}>'
def T(path_en, path_ar=None):
    """bilingual text from the dictionaries by dotted path"""
    def get(d, p):
        for k in p.split("."):
            d = d[int(k)] if isinstance(d, list) else d[k]
        return d
    return B(get(EN, path_en), get(AR, path_ar or path_en))

def head(base, title_en, title_ar, desc_en, desc_ar, noindex=False):
    return f'''<!doctype html>
<html lang="en" dir="ltr" data-t-en="{e(title_en)}" data-t-ar="{e(title_ar)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title_en)}</title>
<meta name="description" content="{e(desc_en)}">
<meta name="theme-color" content="#F2F0E9">
{'<meta name="robots" content="noindex">' if noindex else ''}
<meta property="og:type" content="website"><meta property="og:title" content="{e(title_en)}"><meta property="og:description" content="{e(desc_en)}"><meta property="og:image" content="{base}assets/img/og.svg">
<link rel="icon" href="{base}assets/img/favicon.svg" type="image/svg+xml">
<link rel="preload" href="{base}assets/fonts/schibsted-grotesk-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{base}assets/style.css">
<script>try{{var l=localStorage.getItem("cs_lang");if(l==="ar"||l==="en"){{var h=document.documentElement;h.lang=l;h.dir=l==="ar"?"rtl":"ltr";}}}}catch(e){{}}</script>
</head>
<body>
<a class="skip" href="#main">{B(EN["skip"], AR["skip"])}</a>
'''

NAV = [("work", "work.html"), ("services", "services.html"), ("studio", "studio.html"), ("process", "process.html"), ("contact", "contact.html")]
def header(base, cur=""):
    links = "".join(f'<a href="{base}{h}"{" aria-current=page" if cur==h else ""}>{T("nav."+k)}</a>' for k, h in NAV)
    mlinks = "".join(f'<a class="ml" href="{base}{h}">{T("nav."+k)}</a>' for k, h in NAV)
    return f'''<header class="site-header"><div class="frame hbar">
<a class="logo" href="{base}index.html" data-base="{base}" aria-label="CODINGـSystems"><span translate="no">CODING<span class="tat">ـ</span>Systems</span></a>
<nav class="nav" aria-label="Primary">{links}</nav>
<div class="hright">
<button class="lang" type="button" data-aria-en="Switch language to Arabic" data-aria-ar="تغيير اللغة إلى الإنجليزية" aria-label="Switch language"><span class="en" lang="ar">العربية</span><span class="ar" lang="en">English</span></button>
<a class="btn btn-ink hcta" style="padding:10px 20px" href="{base}start-project.html">{T("nav.start")}</a>
<button class="menu-btn" id="menu-btn" type="button" aria-expanded="false" aria-controls="mobile"><span style="position:absolute;left:-9999px">{T("nav.menu")}</span><svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden="true"><path d="M3 9h20M3 17h20" stroke="currentColor" stroke-width="1.6"/></svg></button>
</div></div>
<div class="mobile" id="mobile"><nav aria-label="Mobile">{mlinks}<div style="margin-top:32px"><a class="btn btn-ink" href="{base}start-project.html">{T("nav.start")}</a></div></nav></div>
</header>
<main id="main">
'''

def footer(base):
    sv = "".join(f'<li><a href="{base}services/{s["slug"]}.html">{B(s["en"]["title"], s["ar"]["title"])}</a></li>' for s in SERVICES)
    pages = "".join(f'<li><a href="{base}{h}">{T("nav."+k)}</a></li>' for k, h in NAV) + f'<li><a href="{base}start-project.html">{T("nav.start")}</a></li>'
    return f'''</main>
<footer class="foot dark"><div class="frame">
<div class="cols">
<div><a class="logo" href="{base}index.html" data-base="{base}" style="font-size:1.9rem"><span translate="no">CODING<span class="tat">ـ</span>Systems</span></a>
<p class="muted" style="max-width:24rem;margin-top:24px">{T("hero.statement")}</p>
<ul style="margin-top:28px;color:var(--soft)"><li>{T("footer.whatsapp")}: <a data-link="whatsapp" href="#" style="color:var(--ivory)" class="ltr js-phone" target="_blank" rel="noopener noreferrer"></a></li>
<li data-email>{T("footer.email")}: <a style="color:var(--ivory)" class="ltr" href="#"></a></li></ul></div>
<nav aria-label="{e(EN["footer"]["services"])}"><h2>{T("footer.services")}</h2><ul>{sv}</ul></nav>
<div style="display:grid;gap:40px"><nav aria-label="{e(EN["footer"]["pages"])}"><h2>{T("footer.pages")}</h2><ul>{pages}</ul></nav>
<div><h2>{T("footer.follow")}</h2><ul class="soc"><li><a data-link="whatsapp" href="#" target="_blank" rel="noopener noreferrer">{T("footer.whatsapp")}</a></li><li><a data-link="tiktok" href="#" target="_blank" rel="noopener noreferrer">{T("footer.tiktok")}</a></li><li><a data-link="instagram" href="#" target="_blank" rel="noopener noreferrer">{T("footer.instagram")}</a></li></ul></div></div>
</div></div>
<div style="border-top:1px solid #44443F"><div class="frame bar" style="display:flex;flex-wrap:wrap;gap:12px 32px;justify-content:space-between;padding-block:22px;font-size:.85rem;color:var(--mute)">
<p style="margin:0">© <span class="js-year">2026</span> <span translate="no">CODINGـSystems</span>. {T("footer.rights")}</p>
<p style="margin:0;display:flex;gap:24px"><a href="{base}privacy.html">{T("footer.privacy")}</a><a href="{base}terms.html">{T("footer.terms")}</a></p></div></div>
</footer>
<script src="{base}assets/config.js"></script>
'''
def tail(base, i18n=False):
    return (f'<script src="{base}assets/i18n.js"></script>\n' if i18n else "") + f'<script src="{base}assets/site.js" defer></script>\n</body>\n</html>\n'

def write(path, content):
    full = os.path.join(ROOT, path); os.makedirs(os.path.dirname(full), exist_ok=True)
    open(full, "w", encoding="utf-8").write(content)

def phead(title_html, lead_html=""):
    lead = f'<div class="c-4 s-9" style="align-self:end">{lead_html}</div>' if lead_html else ""
    return f'<section class="phead"><div class="frame grid12"><h1 class="display c-8">{title_html}</h1>{lead}</div></section>\n'

def cta(base, tone="dark"):
    cls = "dark" if tone == "dark" else ""
    style = "" if tone == "dark" else "background:var(--paper);border-top:1px solid var(--hair)"
    return f'''<section class="sec {cls}" style="{style}"><div class="frame">
<h2 class="display" style="font-size:clamp(2.6rem,8.5vw,8rem);max-width:70rem">{T("cta.title")}</h2>
<div style="margin-top:48px;display:flex;flex-wrap:wrap;gap:32px;justify-content:space-between;align-items:flex-end"><p class="muted" style="max-width:28rem;font-size:1.15rem;margin:0">{T("cta.text")}</p>
<div class="btns"><a class="btn btn-ink" href="{base}start-project.html">{T("cta.button")}{ARROW}</a><a class="btn btn-line" data-link="whatsapp" href="#" target="_blank" rel="noopener noreferrer">{T("cta.whatsapp")}</a></div></div></div></section>
'''

def svc_index(base, dark=False):
    li = "".join(f'<li><a href="{base}services/{s["slug"]}.html"><span class="n">{i+1:02d}</span><span class="t">{B(s["en"]["title"], s["ar"]["title"])}</span><span class="muted">{B(s["en"]["summary"], s["ar"]["summary"])}</span><span class="arrow-wrap">{ARROW}</span></a></li>' for i, s in enumerate(SERVICES))
    return f'<ol class="idx">{li}</ol>'

def work_card(base, c, large=False):
    return f'''<article class="card{' lg' if large else ''}"><a href="{base}work/{c["slug"]}.html"><div class="cover"><img src="{base}assets/img/{os.path.basename(c["art"])}" alt="" loading="lazy" width="1600" height="1000"><span class="tag">{T("work.concept")}</span></div>
<h3>{B(c["titleEn"], c["titleAr"])}</h3><p class="muted" style="margin:0">{B(c["categoryEn"], c["categoryAr"])}</p></a></article>'''

# ───────────────────────── i18n.js (for wizard + contact) ─────────────────────────
def i18n_block(L, extra):
    w = L["wizard"]
    return {
        "errors": L["errors"], "serviceNames": w["serviceNames"], "timelines": w["timelines"], "methods": w["methods"],
        "contact": {**{k: L["contact"][k] for k in ("name", "phone", "subject", "success")}, **extra["contact"]},
        "wizard": {**{k: w[k] for k in ("stepOf", "steps", "edit", "s2", "s3", "s4", "s5", "s7", "labels", "successTitle", "success", "failTitle", "failText")}, "stepTitles": [w["s1"]["title"], w["s2"]["title"], w["s3"]["title"], w["s4"]["title"], w["s5"]["title"], w["s7"]["title"]], **extra["wizard"]},
    }
EXTRA = {
    "en": {"contact": {"waHello": "Hello CODINGـSystems, I would like to get in touch.", "emailShort": "Email", "waNote": "WhatsApp opened with your message. Nothing is sent until you press send inside WhatsApp.", "mailNote": "Your email app opened with the message. Nothing is sent until you press send there."},
           "wizard": {"steps": ["Services", "Idea", "Resources", "Budget", "Contact", "Review & send"], "waHello": "Hello CODINGـSystems, I would like to start a project:", "waTitle2": "WhatsApp opened with your request.", "waNote2": "Nothing has been sent yet. Please press send inside WhatsApp to deliver your request. You can attach files and screenshots there too."}},
    "ar": {"contact": {"waHello": "مرحبًا CODINGـSystems، حابب أتواصل معاكم.", "emailShort": "البريد", "waNote": "اتفتح واتساب برسالتك. مفيش حاجة اتبعتت لحد ما تضغط إرسال جوّه واتساب.", "mailNote": "اتفتح تطبيق البريد بالرسالة. مفيش حاجة اتبعتت لحد ما تضغط إرسال هناك."},
           "wizard": {"steps": ["الخدمات", "الفكرة", "الموارد", "الميزانية", "التواصل", "المراجعة والإرسال"], "waHello": "مرحبًا CODINGـSystems، حابب أبدأ مشروع:", "waTitle2": "اتفتح واتساب بطلبك.", "waNote2": "لسه مفيش حاجة اتبعتت. اضغط إرسال جوّه واتساب عشان يوصلنا طلبك. وتقدر تبعت ملفات ولقطات شاشة من هناك كمان."}},
}
WIZ_ONLY_FIX = {"en": {"labels": None}, "ar": {}}
i18n = {"en": i18n_block(EN, EXTRA["en"]), "ar": i18n_block(AR, EXTRA["ar"]), "budgets": [{"value": v, "labelEn": a, "labelAr": b} for v, a, b in BUDGETS]}
write("assets/i18n.js", "/* generated by _tools/build.py */\nwindow.CS_I18N = " + json.dumps(i18n, ensure_ascii=False) + ";\n")

# ───────────────────────── pages ─────────────────────────
def page(path, base, title, desc, body, cur="", i18n_js=False, noindex=False):
    write(path, head(base, title[0], title[1], desc[0], desc[1], noindex) + header(base, cur) + body + footer(base) + tail(base, i18n_js))

SUF = " — CODINGـSystems"
# HOME
work3 = "".join(work_card("", c, large=(i == 0)) for i, c in enumerate(CONCEPTS))
pillars = "".join(f'<div><h3 class="serif" style="font-size:1.6rem;margin:0">{B(EN["studio"]["pillars"][i][0], AR["studio"]["pillars"][i][0])}</h3><p class="muted" style="max-width:22rem">{B(EN["studio"]["pillars"][i][1], AR["studio"]["pillars"][i][1])}</p></div>' for i in range(3))
caps = "".join(f'<li>{B(EN["capabilities"]["items"][i], AR["capabilities"]["items"][i])}</li>' for i in range(8))
steps = "".join(f'<li><span class="n">{i+1:02d}</span><h3>{B(EN["process"]["steps"][i][0], AR["process"]["steps"][i][0])}</h3><p class="muted" style="max-width:20rem;margin:0">{B(EN["process"]["steps"][i][1], AR["process"]["steps"][i][1])}</p></li>' for i in range(6))
home = f'''<section class="hero"><div class="frame">
<h1 class="display"><span class="hl"><span>{T("hero.l1")}</span></span><span class="hl"><span>{T("hero.l2")}</span></span></h1>
<div class="hero-art"><img src="assets/img/hero.svg" alt="{e(EN["hero"]["figure"])}" width="1200" height="1200" fetchpriority="high"></div>
<div class="hero-bottom"><p class="st">{T("hero.statement")}</p><p class="muted" style="max-width:24rem;margin:0">{T("hero.sub")}</p>
<div class="btns"><a class="btn btn-ink" href="start-project.html">{T("hero.cta1")}{ARROW}</a><a class="btn btn-line" href="work.html">{T("hero.cta2")}</a></div></div></div></section>
<section class="dark sec"><div class="frame grid12"><h2 class="display c-9" style="font-size:clamp(2.4rem,7.2vw,6.8rem)">{T("studio.title")}</h2>
<div class="c-4 s-9 muted" style="font-size:1.15rem"><p style="margin-top:0">{T("studio.p1")}</p><p>{T("studio.p2")}</p></div>
<div class="c-12 rule" style="display:grid;gap:40px;padding-top:40px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">{pillars}</div></div></section>
<section class="sec bb"><div class="frame"><div style="display:flex;justify-content:space-between;align-items:flex-end;gap:24px;margin-bottom:56px"><h2 class="h2" style="font-size:clamp(2.2rem,6vw,5rem)">{T("work.title")}</h2><a href="work.html" class="btn btn-line" style="padding:10px 18px">{T("work.all")}</a></div>
<div class="work home">{work3}</div><p class="muted" style="max-width:40rem;font-size:.9rem;margin-top:48px">{T("work.conceptNote")}</p></div></section>
<section class="dark sec"><div class="frame"><div class="grid12" style="margin-bottom:48px"><h2 class="h2 c-7" style="font-size:clamp(2.2rem,6vw,5rem)">{T("services.title")}</h2><p class="serif c-4 s-9 muted" style="font-size:1.35rem;align-self:end;margin:0">{T("services.lead")}</p></div>{svc_index("")}</div></section>
<section class="sec bb"><div class="frame grid12"><h2 class="h2 c-5" style="font-size:clamp(2.2rem,6vw,5rem)">{T("capabilities.title")}</h2><ul class="plain c-6 s-7">{caps}</ul></div></section>
<section class="dark charcoal sec"><div class="frame"><div style="display:flex;justify-content:space-between;align-items:flex-end;gap:24px;margin-bottom:56px"><h2 class="h2" style="font-size:clamp(2.2rem,6vw,5rem)">{T("process.title")}</h2><a href="process.html" class="btn btn-line" style="padding:10px 18px">{T("process.title")}</a></div><ol class="steps">{steps}</ol></div></section>
{cta("", "light")}'''
page("index.html", "", (EN["hero"]["l1"] + " " + EN["hero"]["l2"] + SUF, "من الفكرة للتنفيذ" + SUF), ("Digital products. Thoughtful design. Solid engineering. We design and build websites, custom web applications and business systems.", AR["hero"]["statement"]), home, cur="index.html")

# SERVICES
page("services.html", "", (EN["services"]["title"] + SUF, AR["services"]["title"] + SUF), (EN["services"]["lead"], AR["services"]["lead"]),
     phead(T("services.title"), f'<p class="lead">{T("services.lead")}</p>') + f'<section><div class="frame sec">{svc_index("")}</div></section>' + cta(""), cur="services.html")
for s in SERVICES:
    rel = [c for c in CONCEPTS if c["service"] == s["code"]]
    cases = "" if not rel else f'<section class="bb"><div class="frame sec"><h2 class="h2" style="font-size:clamp(2rem,5vw,3.5rem);margin-bottom:48px">{T("services.cases")}</h2><div class="work" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">' + "".join(work_card("../", c) for c in rel) + "</div></div></section>"
    li = lambda arr_en, arr_ar, cls="": "".join(f'<li>{B(a, b)}</li>' for a, b in zip(arr_en, arr_ar))
    body = f'''<section class="phead"><div class="frame grid12"><div class="c-12"><a href="../services.html" class="muted" style="font-size:.9rem">← {T("services.back")}</a></div>
<h1 class="display c-8" style="font-size:clamp(2.8rem,8vw,7rem)">{B(s["en"]["title"], s["ar"]["title"])}</h1>
<div class="c-4 s-9" style="align-self:end"><p class="lead">{B(s["en"]["summary"], s["ar"]["summary"])}</p><p style="margin-top:32px"><a class="btn btn-ink" href="../start-project.html?service={s["code"]}">{T("services.inquire")}{ARROW}</a></p></div></div></section>
<section class="bb"><div class="frame sec grid12"><div class="c-5"><h2 class="h2" style="font-size:clamp(1.9rem,4vw,3.2rem)">{T("services.problem")}</h2><p class="muted" style="font-size:1.15rem;margin-top:24px">{B(s["en"]["problem"], s["ar"]["problem"])}</p></div>
<div class="c-6 s-7"><h2 class="h2" style="font-size:clamp(1.9rem,4vw,3.2rem)">{T("services.solution")}</h2><p class="muted" style="font-size:1.15rem;margin-top:24px">{B(s["en"]["solution"], s["ar"]["solution"])}</p></div></div></section>
<section class="dark sec"><div class="frame grid12"><div class="c-6"><h2 class="h2" style="font-size:2.2rem;margin-bottom:32px">{T("services.features")}</h2><ul class="plain">{li(s["en"]["features"], s["ar"]["features"])}</ul></div>
<div class="c-6"><h2 class="h2" style="font-size:2.2rem;margin-bottom:32px">{T("services.deliverables")}</h2><ul class="plain" style="color:var(--soft)">{li(s["en"]["deliverables"], s["ar"]["deliverables"])}</ul></div></div></section>
{cases}{cta("../")}'''
    page(f"services/{s['slug']}.html", "../", (s["en"]["title"] + SUF, s["ar"]["title"] + SUF), (s["en"]["summary"], s["ar"]["summary"]), body, cur="services.html")

# WORK
allw = "".join(work_card("", c) for c in CONCEPTS)
page("work.html", "", (EN["work"]["title"] + SUF, AR["work"]["title"] + SUF), (EN["work"]["conceptNote"], AR["work"]["conceptNote"]),
     phead(T("work.title"), f'<p class="muted">{T("work.conceptNote")}</p>') + f'<section><div class="frame sec"><div class="work all">{allw}</div></div></section>' + cta(""), cur="work.html")
for c in CONCEPTS:
    blk = lambda h, en, ar: f'<div class="block"><h2>{T(h)}</h2><p>{B(en, ar)}</p></div>'
    feats = "".join(f'<li>{B(a, b)}</li>' for a, b in zip(c["featuresEn"], c["featuresAr"]))
    body = f'''<section class="phead"><div class="frame"><a href="../work.html" class="muted" style="font-size:.9rem">← {T("work.back")}</a>
<div class="grid12" style="margin-top:32px"><h1 class="display c-9" style="font-size:clamp(2.8rem,8vw,7rem)">{B(c["titleEn"], c["titleAr"])}</h1><div class="c-3" style="align-self:end"><p class="muted" style="margin:0 0 8px">{B(c["categoryEn"], c["categoryAr"])}</p><span class="tagi">{T("work.concept")}</span></div></div>
<img src="../assets/img/{os.path.basename(c["art"])}" alt="" style="width:100%;aspect-ratio:16/9;object-fit:cover;margin-top:56px;background:var(--soft)" width="1600" height="1000"></div></section>
<section><div class="frame sec"><p class="note" style="margin:0 0 40px">{T("work.conceptNote")}</p>
{blk("work.overview", c["overviewEn"], c["overviewAr"])}{blk("work.challenge", c["challengeEn"], c["challengeAr"])}{blk("work.solution", c["solutionEn"], c["solutionAr"])}
<div class="block"><h2>{T("work.features")}</h2><ul class="plain" style="border:0">{feats}</ul></div>
<div class="block"><h2>{T("work.tech")}</h2><p dir="ltr" style="font-family:var(--sans)">{e(", ".join(c["tech"]))}</p></div>
<div class="block"><h2>{T("work.results")}</h2><p>{T("work.noResults")}</p></div>
<div class="rule" style="padding-top:40px"><a class="btn btn-ink" href="../start-project.html?service={c["service"]}">{T("work.next")}{ARROW}</a></div></div></section>{cta("../")}'''
    page(f"work/{c['slug']}.html", "../", (c["titleEn"] + SUF, c["titleAr"] + SUF), (c["overviewEn"], c["overviewAr"]), body, cur="work.html")

# STUDIO
pill_cols = "".join(f'<div class="rule" style="padding-top:24px"><h3 class="serif" style="font-size:1.9rem;margin:0">{B(EN["studio"]["pillars"][i][0], AR["studio"]["pillars"][i][0])}</h3><p class="muted">{B(EN["studio"]["pillars"][i][1], AR["studio"]["pillars"][i][1])}</p></div>' for i in range(3))
page("studio.html", "", (EN["studio"]["page"]["title"] + SUF, AR["studio"]["page"]["title"] + SUF), (EN["studio"]["page"]["lead"], AR["studio"]["page"]["lead"]),
     phead(T("studio.page.title"), f'<p class="lead">{T("studio.page.lead")}</p>') +
     f'<section class="bb"><div class="frame sec grid12"><h2 class="h2 c-7" style="font-size:clamp(2rem,5vw,4.2rem)">{T("studio.title")}</h2><div class="c-4 s-9 muted" style="font-size:1.15rem"><p style="margin-top:0">{T("studio.p1")}</p><p>{T("studio.p2")}</p><p>{T("studio.page.body")}</p></div></div></section>'
     f'<section class="dark sec"><div class="frame" style="display:grid;gap:40px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">{pill_cols}</div></section>'
     f'<section class="sec"><div class="frame grid12"><h2 class="h2 c-5" style="font-size:clamp(2rem,5vw,4rem)">{T("capabilities.title")}</h2><ul class="plain c-6 s-7">{caps}</ul></div></section>' + cta(""), cur="studio.html")

# PROCESS
rows = "".join(f'<li class="prow"><span class="big">{i+1:02d}</span><h2>{B(EN["process"]["steps"][i][0], AR["process"]["steps"][i][0])}</h2><p class="muted" style="font-size:1.15rem;max-width:28rem;margin:0">{B(EN["process"]["steps"][i][1], AR["process"]["steps"][i][1])}</p></li>' for i in range(6))
page("process.html", "", (EN["process"]["title"] + SUF, AR["process"]["title"] + SUF), (EN["process"]["lead"], AR["process"]["lead"]),
     phead(T("process.title"), f'<p class="lead">{T("process.lead")}</p>') + f'<section><div class="frame sec"><ol style="list-style:none;margin:0;padding:0;border-top:1px solid var(--hair)">{rows}</ol></div></section>' + cta(""), cur="process.html")

# LEGAL
for key, fn in (("privacy", "privacy.html"), ("terms", "terms.html")):
    items = "".join(f'<div class="block" style="grid-template-columns:1fr"><h2 style="font-size:1.6rem">{B(EN["legal"][key][i][0], AR["legal"][key][i][0])}</h2><p style="font-family:var(--sans);font-size:1.1rem">{B(EN["legal"][key][i][1], AR["legal"][key][i][1])}</p></div>' for i in range(len(EN["legal"][key])))
    tk = key + "Title"
    page(fn, "", (EN["legal"][tk] + SUF, AR["legal"][tk] + SUF), (EN["legal"][tk], AR["legal"][tk]),
         phead(T("legal." + tk)) + f'<section><div class="frame sec" style="max-width:56rem">{items}<p class="muted rule" style="padding-top:24px;font-size:.9rem">{T("legal.note")}</p></div></section>')

# CONTACT
def field(name, en_l, ar_l, typ="text", req=False, ltr=False, area=False):
    d = ' dir="ltr"' if ltr else ""
    inp = (f'<textarea class="field" id="c-{name}" name="{name}" rows="6" maxlength="3000"></textarea>' if area else f'<input class="field" id="c-{name}" name="{name}" type="{typ}"{d} maxlength="200" autocomplete="off">')
    return f'<div><label class="l" for="c-{name}">{B(en_l, ar_l)}{" *" if req else ""}</label>{inp}<p class="err" data-err="{name}" hidden></p></div>'
contact_body = phead(T("contact.title"), f'<p class="lead">{T("contact.lead")}</p>') + f'''<section><div class="frame sec grid12">
<div class="c-7"><form id="contact-form" class="stack" novalidate>
{field("name", EN["contact"]["name"], AR["contact"]["name"], req=True)}
<div class="two">{field("phone", EN["contact"]["phone"], AR["contact"]["phone"], "tel", ltr=True)}{field("email", EN["contact"]["email"], AR["contact"]["email"], "email", ltr=True)}</div>
<p class="muted" style="margin:-12px 0 0;font-size:.9rem">{T("contact.phoneOrEmail")}</p>
{field("subject", EN["contact"]["subject"], AR["contact"]["subject"])}{field("message", EN["contact"]["message"], AR["contact"]["message"], req=True, area=True)}
<div class="hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>
<div class="btns"><button type="button" class="btn btn-ink" id="c-wa">{B("SEND VIA WHATSAPP", "أرسل عبر واتساب")}</button><button type="button" class="btn btn-line" id="c-send" hidden>{T("contact.send")}</button><button type="button" class="btn btn-line" id="c-mail">{B("SEND BY EMAIL", "أرسل بالبريد")}</button></div>
<div id="contact-out" class="box" tabindex="-1" hidden></div></form></div>
<aside class="c-4 s-9" style="display:grid;gap:40px;align-content:start"><div><h2 class="muted" style="font-size:.85rem;margin:0">{T("contact.direct")}</h2>
<ul style="list-style:none;padding:0;margin:16px 0 0;font-size:1.15rem;display:grid;gap:8px"><li><a class="ltr js-phone" data-link="whatsapp" href="#" target="_blank" rel="noopener noreferrer"></a></li><li data-email><a class="ltr" href="#"></a></li></ul>
<ul class="soc" style="list-style:none;padding:0;margin:20px 0 0"><li><a data-link="whatsapp" href="#" target="_blank" rel="noopener noreferrer">{T("footer.whatsapp")}</a></li><li><a data-link="tiktok" href="#" target="_blank" rel="noopener noreferrer">{T("footer.tiktok")}</a></li><li><a data-link="instagram" href="#" target="_blank" rel="noopener noreferrer">{T("footer.instagram")}</a></li></ul></div>
<div class="rule" style="padding-top:28px"><p class="muted" style="margin-top:0">{T("contact.orStart")}</p><a class="btn btn-ink" href="start-project.html">{T("nav.start")}{ARROW}</a></div></aside></div></section>'''
page("contact.html", "", (EN["contact"]["title"] + SUF, AR["contact"]["title"] + SUF), (EN["contact"]["lead"], AR["contact"]["lead"]), contact_body, cur="contact.html", i18n_js=True)

# START PROJECT (wizard)
W, WA = EN["wizard"], AR["wizard"]
def wf(name, en_l, ar_l, typ="text", area=False, req=False, ltr=False, hint=None, rows=4):
    d = ' dir="ltr"' if ltr else ""
    inp = f'<textarea class="field" id="w-{name}" name="{name}" rows="{rows}" maxlength="3000"></textarea>' if area else f'<input class="field" id="w-{name}" name="{name}" type="{typ}"{d} maxlength="250" autocomplete="off">'
    h = f'<p class="muted" style="margin:-4px 0 8px;font-size:.9rem">{hint}</p>' if hint else ""
    return f'<div><label class="l" for="w-{name}">{B(en_l, ar_l)}{" *" if req else ""}</label>{h}{inp}<p class="err" data-err="{name}" hidden></p></div>'
opts = lambda name, items, typ: "".join(f'<label class="opt"><input type="{typ}" name="{name}" value="{v}"><span>{B(a, b)}</span></label>' for v, a, b in items)
svc_opts = opts("services", [(c, W["serviceNames"][c], WA["serviceNames"][c]) for c in SERVICE_CODES], "checkbox")
bud_opts = opts("budget", BUDGETS, "radio")
meth = opts("method", [(m, W["methods"][m], WA["methods"][m]) for m in ("whatsapp", "phone", "email")], "radio").replace('value="whatsapp"', 'value="whatsapp" checked')
tl = "".join(f'<option value="{t}">{e(W["timelines"][t])} / {e(WA["timelines"][t])}</option>' for t in TIMELINES)
tl_opts = '<option value="">—</option>' + "".join(f'<option value="{t}">{e(W["timelines"][t])} — {e(WA["timelines"][t])}</option>' for t in TIMELINES)
S1, S2, S3, S4, S5 = (lambda k: W[k]), None, None, None, None
wiz = f'''<section><div class="frame" style="max-width:64rem;padding-block:clamp(48px,7vw,96px)"><div class="wiz">
<p id="stepinfo" style="font-weight:600;font-size:.9rem" class="muted" aria-live="polite"></p>
<ol class="wiz-prog" id="prog" aria-hidden="true">{"<li></li>"*6}</ol>
<h1 class="display" id="stitle" tabindex="-1"></h1>
<noscript><p class="note">{B("This form needs JavaScript. You can also message us directly on WhatsApp.", "النموذج محتاج JavaScript. تقدر كمان تكلمنا مباشرة على واتساب.")}</p></noscript>
<form id="wiz" class="stack" style="margin-top:48px" novalidate>
<div class="hp" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div>
<div data-step="0"><p class="legend">{T("wizard.s1.hint")}</p><div class="opts" role="group" aria-label="{e(W["s1"]["title"])}">{svc_opts}</div><p class="err" data-err="services" hidden></p></div>
<div data-step="1" class="stack" hidden>{wf("projectName", W["s2"]["projectName"], WA["s2"]["projectName"])}{wf("description", W["s2"]["description"], WA["s2"]["description"], area=True, req=True, rows=6, hint=B(W["s2"]["descHint"], WA["s2"]["descHint"]))}{wf("businessProblem", W["s2"]["problem"], WA["s2"]["problem"], area=True)}{wf("targetAudience", W["s2"]["audience"], WA["s2"]["audience"], area=True, rows=3)}{wf("requiredFeatures", W["s2"]["features"], WA["s2"]["features"], area=True)}{wf("referenceUrls", W["s2"]["refs"], WA["s2"]["refs"], area=True, rows=3, ltr=True, hint=B(W["s2"]["refsHint"], WA["s2"]["refsHint"]))}</div>
<div data-step="2" class="two" hidden>{wf("existingWebsite", W["s3"]["website"], WA["s3"]["website"], ltr=True)}{wf("domain", W["s3"]["domain"], WA["s3"]["domain"], ltr=True)}{wf("hosting", W["s3"]["hosting"], WA["s3"]["hosting"])}{wf("existingDatabase", W["s3"]["database"], WA["s3"]["database"])}
<div style="grid-column:1/-1">{wf("existingDesign", W["s3"]["design"], WA["s3"]["design"], area=True, rows=3)}</div><div style="grid-column:1/-1">{wf("integrations", W["s3"]["integrations"], WA["s3"]["integrations"], area=True, rows=3)}</div><div style="grid-column:1/-1">{wf("additionalRequirements", W["s3"]["additional"], WA["s3"]["additional"], area=True, rows=3)}</div></div>
<div data-step="3" class="stack" hidden><div><p class="legend">{B(W["s4"]["budget"] + " *", WA["s4"]["budget"] + " *")}</p><p class="muted" style="font-size:.9rem;margin:-4px 0 14px">{T("wizard.s4.note")}</p><div class="opts" role="radiogroup">{bud_opts}</div><p class="err" data-err="budget" hidden></p></div>
<div><label class="l" for="w-timeline">{T("wizard.s4.timeline")}</label><select class="field" id="w-timeline" name="timeline">{tl_opts}</select></div>{wf("deadline", W["s4"]["deadline"], WA["s4"]["deadline"])}</div>
<div data-step="4" class="two" hidden>{wf("fullName", W["s5"]["name"], WA["s5"]["name"], req=True)}{wf("phone", W["s5"]["phone"], WA["s5"]["phone"], "tel", req=True, ltr=True)}
<div style="grid-column:1/-1"><p class="legend">{B(W["s5"]["method"] + " *", WA["s5"]["method"] + " *")}</p><div class="opts" role="radiogroup" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">{meth}</div></div>
{wf("company", W["s5"]["company"], WA["s5"]["company"])}{wf("email", W["s5"]["email"], WA["s5"]["email"], "email", ltr=True)}{wf("whatsapp", W["s5"]["whatsapp"], WA["s5"]["whatsapp"], "tel", ltr=True)}</div>
<div data-step="5" class="stack" hidden><dl class="review" id="review-list"></dl>
<p class="note" style="margin:0">{B("Files: this static site cannot store attachments. After the WhatsApp message opens you can attach documents, reference images and screenshots in the same chat.", "الملفات: الموقع الثابت ده مش بيخزّن مرفقات. بعد ما واتساب يفتح تقدر تبعت المستندات والصور المرجعية ولقطات الشاشة في نفس المحادثة.")}</p>
<div id="result" class="box" tabindex="-1" hidden><h2 class="h2" style="font-size:clamp(1.8rem,4vw,3rem)"></h2><p class="msg" style="font-size:1.15rem"></p></div></div>
<div style="display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;border-top:1px solid var(--hair);padding-top:32px">
<button type="button" class="btn btn-line" id="back" hidden>{T("wizard.back")}</button>
<span style="display:flex;gap:12px;flex-wrap:wrap;margin-inline-start:auto"><button type="button" class="btn btn-ink" id="next">{T("wizard.next")}{ARROW}</button>
<span id="final" class="btns" hidden><button type="button" class="btn btn-ink" id="send-wa">{B("SEND VIA WHATSAPP", "أرسل عبر واتساب")}{ARROW}</button><button type="button" class="btn btn-line" id="send-ep">{T("wizard.submit")}</button></span></span></div>
</form></div></div></section>'''
page("start-project.html", "", (EN["wizard"]["title"] + SUF, AR["wizard"]["title"] + SUF), (EN["wizard"]["lead"], AR["wizard"]["lead"]), wiz, i18n_js=True)

# 404
page("404.html", "", ("404" + SUF, "404" + SUF), ("Page not found", "الصفحة مش موجودة"),
     f'<section><div class="frame" style="padding-block:clamp(80px,12vw,160px)"><p aria-hidden="true" style="font-size:clamp(6rem,22vw,20rem);font-weight:600;letter-spacing:-.05em;line-height:.8;color:var(--hair);margin:0">404</p><h1 class="h2" style="font-size:clamp(2.2rem,6vw,4rem);margin-top:32px">{T("states.notFoundTitle")}</h1><p class="muted" style="font-size:1.15rem;max-width:28rem">{T("states.notFoundText")}</p><a class="btn btn-ink" href="index.html" style="margin-top:32px">{T("states.home")}</a></div></section>', noindex=True)

# robots / sitemap
pages_list = ["index.html", "services.html", "work.html", "studio.html", "process.html", "contact.html", "start-project.html", "privacy.html", "terms.html"] + [f"services/{s['slug']}.html" for s in SERVICES] + [f"work/{c['slug']}.html" for c in CONCEPTS]
write("robots.txt", "User-agent: *\nAllow: /\n" + (f"Sitemap: {SITE_URL}/sitemap.xml\n" if SITE_URL else ""))
if SITE_URL:
    write("sitemap.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "".join(f"<url><loc>{SITE_URL}/{p}</loc></url>\n" for p in pages_list) + "</urlset>\n")
print("generated", len(pages_list) + 1, "pages")
