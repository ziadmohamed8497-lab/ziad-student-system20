/* ───────────────────────────────────────────────────────────────
   CODINGـSystems — site configuration. Edit this file only; no other code needs to change.
   ─────────────────────────────────────────────────────────────── */
window.CS_CONFIG = {
  companyName: "CODINGـSystems",
  whatsapp: "https://wa.me/201278910793",
  phone: "+201278910793",
  tiktok: "https://www.tiktok.com/@codingsystems?_r=1&_t=zs-99vgq3nuric",
  instagram: "https://www.instagram.com/coding_systems25/",

  // Business e-mail. Leave empty and every e-mail element stays hidden.
  email: "",

  // Official logo: put the files in assets/img/ and write the paths, e.g. "assets/img/logo.svg".
  // Leave both empty to keep the temporary text wordmark. logoDark is used on dark backgrounds (footer).
  logoLight: "",
  logoDark: "",

  // OPTIONAL: a form-backend URL (Formspree, Getform, Basin, Web3Forms …) that accepts a JSON POST.
  // When set, the forms show an extra "Send request" button; success is shown ONLY if that service answers OK.
  // When empty, requests are sent by opening WhatsApp with a prefilled message.
  formEndpoint: ""
};
