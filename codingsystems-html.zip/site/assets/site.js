(function () {
  "use strict";
  var C = window.CS_CONFIG || {};
  var html = document.documentElement;
  var I = window.CS_I18N || null;

  /* ── language ───────────────────────────────────────────── */
  function lang() { return html.lang === "ar" ? "ar" : "en"; }
  function applyLang(l) {
    html.lang = l; html.dir = l === "ar" ? "rtl" : "ltr";
    var t = html.getAttribute("data-t-" + l); if (t) document.title = t;
    document.querySelectorAll("[data-ph-en]").forEach(function (el) { el.placeholder = el.getAttribute("data-ph-" + l) || ""; });
    document.querySelectorAll("[data-aria-en]").forEach(function (el) { el.setAttribute("aria-label", el.getAttribute("data-aria-" + l)); });
    document.querySelectorAll(".lang").forEach(function (b) { b.setAttribute("lang", l === "ar" ? "en" : "ar"); });
    document.dispatchEvent(new CustomEvent("cs:lang", { detail: l }));
  }
  document.querySelectorAll(".lang").forEach(function (b) {
    b.addEventListener("click", function () {
      var n = lang() === "ar" ? "en" : "ar";
      try { localStorage.setItem("cs_lang", n); } catch (e) {} // stores only the language preference
      applyLang(n);
    });
  });
  applyLang(lang());

  /* ── mobile menu ────────────────────────────────────────── */
  var mb = document.getElementById("menu-btn"), mm = document.getElementById("mobile");
  if (mb && mm) {
    var close = function () { mm.classList.remove("open"); mb.setAttribute("aria-expanded", "false"); document.body.style.overflow = ""; };
    mb.addEventListener("click", function () {
      var o = mm.classList.toggle("open"); mb.setAttribute("aria-expanded", o ? "true" : "false"); document.body.style.overflow = o ? "hidden" : "";
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    mm.addEventListener("click", function (e) { if (e.target.closest("a")) close(); });
  }

  /* ── config → DOM ───────────────────────────────────────── */
  document.querySelectorAll("[data-link]").forEach(function (a) { var u = C[a.getAttribute("data-link")]; if (u) a.setAttribute("href", u); else a.hidden = true; });
  document.querySelectorAll(".js-phone").forEach(function (el) { el.textContent = C.phone || ""; });
  document.querySelectorAll("[data-email]").forEach(function (el) {
    if (!C.email) { el.hidden = true; return; }
    var a = el.querySelector("a"); if (a) { a.href = "mailto:" + C.email; a.textContent = C.email; }
  });
  document.querySelectorAll(".js-year").forEach(function (el) { el.textContent = new Date().getFullYear(); });
  document.querySelectorAll(".logo").forEach(function (el) {
    var dark = el.closest(".foot");
    var src = dark ? (C.logoDark || C.logoLight) : C.logoLight;
    if (!src) return;
    var base = el.getAttribute("data-base") || "";
    el.textContent = ""; var img = new Image(); img.src = base + src.replace(/^\//, ""); img.alt = C.companyName || "CODINGـSystems"; el.appendChild(img);
  });

  /* ── helpers shared by wizard + contact ─────────────────── */
  function trunc(s, n) { s = (s || "").trim(); return s.length > n ? s.slice(0, n - 1) + "…" : s; }
  function waUrl(text) {
    var m = (C.whatsapp || "").match(/wa\.me\/(\d+)/);
    return "https://wa.me/" + (m ? m[1] : "201278910793") + "?text=" + encodeURIComponent(text);
  }
  function openWa(text) { window.open(waUrl(text), "_blank", "noopener"); }
  function validPhone(v) { return /^\+?\d{8,15}$/.test((v || "").trim().replace(/[\s\-().]/g, "")); }
  function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((v || "").trim()); }
  function postJson(payload) {
    return fetch(C.formEndpoint, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(payload) })
      .then(function (r) { return r.ok; }).catch(function () { return false; });
  }
  function setErr(form, name, code) {
    var el = form.querySelector('[data-err="' + name + '"]'), inp = form.querySelector('[name="' + name + '"]');
    if (el) { el.textContent = code ? I[lang()].errors[code] : ""; el.hidden = !code; }
    if (inp && inp.type !== "checkbox" && inp.type !== "radio") inp.setAttribute("aria-invalid", code ? "true" : "false");
  }
  window.CS = { lang: lang, trunc: trunc, waUrl: waUrl, openWa: openWa, validPhone: validPhone, validEmail: validEmail, postJson: postJson, setErr: setErr, C: C };

  /* ── contact form ───────────────────────────────────────── */
  var cf = document.getElementById("contact-form");
  if (cf && I) {
    var out = document.getElementById("contact-out");
    var payload = function () { var d = {}; new FormData(cf).forEach(function (v, k) { d[k] = String(v); }); return d; };
    var check = function () {
      var d = payload(), ok = true;
      var rules = { name: d.name.trim().length < 2 ? "name_required" : "", message: d.message.trim().length < 10 ? "message_short" : "", phone: "", email: "" };
      if (!d.phone.trim() && !d.email.trim()) rules.phone = "phone_or_email";
      else { if (d.phone.trim() && !validPhone(d.phone)) rules.phone = "invalid_phone"; if (d.email.trim() && !validEmail(d.email)) rules.email = "invalid_email"; }
      Object.keys(rules).forEach(function (k) { setErr(cf, k, rules[k]); if (rules[k]) ok = false; });
      return ok ? d : null;
    };
    var text = function (d) {
      var L = I[lang()];
      return [L.contact.waHello, "", L.contact.name + ": " + d.name, d.phone ? L.contact.phone + ": " + d.phone : "", d.email ? L.contact.emailShort + ": " + d.email : "", d.subject ? L.contact.subject + ": " + d.subject : "", "", trunc(d.message, 1200)].filter(function (x, i) { return x !== "" || i === 1 || i === 6; }).join("\n");
    };
    var show = function (kind, msg) { out.hidden = false; out.setAttribute("role", kind === "error" ? "alert" : "status"); out.innerHTML = ""; var p = document.createElement("p"); p.textContent = msg; out.appendChild(p); out.focus(); };
    cf.addEventListener("submit", function (e) { e.preventDefault(); });
    document.getElementById("c-wa").addEventListener("click", function () { var d = check(); if (!d) return; openWa(text(d)); show("ok", I[lang()].contact.waNote); });
    var ep = document.getElementById("c-send");
    if (ep) {
      if (!C.formEndpoint) ep.hidden = true;
      ep.addEventListener("click", function () {
        var d = check(); if (!d) return; if (d.website) return; ep.disabled = true;
        postJson({ type: "contact", name: d.name, phone: d.phone, email: d.email, subject: d.subject, message: d.message, language: lang() }).then(function (ok) {
          ep.disabled = false; show(ok ? "ok" : "error", ok ? I[lang()].contact.success : I[lang()].wizard.failText);
        });
      });
    }
    var mail = document.getElementById("c-mail");
    if (mail) { if (!C.email) mail.hidden = true; mail.addEventListener("click", function () { var d = check(); if (!d) return; location.href = "mailto:" + C.email + "?subject=" + encodeURIComponent(d.subject || "CODINGـSystems") + "&body=" + encodeURIComponent(text(d)); show("ok", I[lang()].contact.mailNote); }); }
  }

  /* ── project wizard ─────────────────────────────────────── */
  var wz = document.getElementById("wiz");
  if (wz && I) {
    var steps = Array.prototype.slice.call(wz.querySelectorAll("[data-step]")), cur = 0;
    var title = document.getElementById("stitle"), info = document.getElementById("stepinfo"), prog = document.getElementById("prog");
    var back = document.getElementById("back"), next = document.getElementById("next"), fin = document.getElementById("final"), result = document.getElementById("result");
    var started = Date.now();
    var qs = new URLSearchParams(location.search).get("service");
    if (qs) { var pre = wz.querySelector('input[name="services"][value="' + qs.replace(/[^a-z_]/g, "") + '"]'); if (pre) pre.checked = true; }
    var val = function (n) { var el = wz.elements[n]; return el ? (el.value || "").trim() : ""; };
    var checked = function (n) { return Array.prototype.slice.call(wz.querySelectorAll('input[name="' + n + '"]:checked')).map(function (i) { return i.value; }); };

    function validate(s) {
      var e = {};
      if (s === 0 && !checked("services").length) e.services = "services_required";
      if (s === 1) { if (val("description").length < 20) e.description = "description_short"; }
      if (s === 3 && !checked("budget").length) e.budget = "budget_required";
      if (s === 4) {
        if (val("fullName").length < 2) e.fullName = "name_required";
        if (!validPhone(val("phone"))) e.phone = "invalid_phone";
        if (val("email") && !validEmail(val("email"))) e.email = "invalid_email";
        if (checked("method")[0] === "email" && !val("email")) e.email = "email_required_for_contact";
        if (val("whatsapp") && !validPhone(val("whatsapp"))) e.whatsapp = "invalid_phone";
      }
      ["services", "description", "budget", "fullName", "phone", "email", "whatsapp"].forEach(function (k) { setErr(wz, k, e[k] || ""); });
      return Object.keys(e).length === 0;
    }
    function label(group, v) { var L = I[lang()]; return (L[group] && L[group][v]) || v; }
    function data() {
      var L = I[lang()], b = checked("budget")[0], bl = (I.budgets.filter(function (x) { return x.value === b; })[0] || {});
      return {
        services: checked("services").map(function (v) { return label("serviceNames", v); }),
        projectName: val("projectName"), description: val("description"), businessProblem: val("businessProblem"), targetAudience: val("targetAudience"), requiredFeatures: val("requiredFeatures"), referenceUrls: val("referenceUrls"),
        existingWebsite: val("existingWebsite"), domain: val("domain"), hosting: val("hosting"), existingDatabase: val("existingDatabase"), existingDesign: val("existingDesign"), integrations: val("integrations"), additionalRequirements: val("additionalRequirements"),
        budget: bl[lang() === "ar" ? "labelAr" : "labelEn"] || "", budgetValue: b || "", timeline: val("timeline") ? label("timelines", val("timeline")) : "", deadline: val("deadline"),
        fullName: val("fullName"), phone: val("phone"), method: label("methods", checked("method")[0] || "whatsapp"), company: val("company"), email: val("email"), whatsapp: val("whatsapp")
      };
    }
    function waText(d) {
      var L = I[lang()].wizard, t = trunc, rows = [L.waHello, ""];
      var add = function (k, v, n) { if (v) rows.push(k + ": " + t(v, n || 300)); };
      add(L.labels.services, d.services.join(lang() === "ar" ? "، " : ", "));
      add(L.s2.projectName.replace(/\s*\(.*\)/, ""), d.projectName, 120); add(L.labels.description, d.description, 500);
      add(L.s2.problem, d.businessProblem); add(L.s2.audience, d.targetAudience, 200); add(L.s2.features, d.requiredFeatures);
      add(L.s2.refs, d.referenceUrls, 250);
      add(L.s3.website, d.existingWebsite, 120); add(L.s3.domain, d.domain, 80); add(L.s3.hosting, d.hosting, 80); add(L.s3.database, d.existingDatabase, 120); add(L.s3.integrations, d.integrations, 200); add(L.s3.additional, d.additionalRequirements, 250);
      add(L.labels.budget, d.budget); add(L.labels.timeline, d.timeline); add(L.s4.deadline, d.deadline, 120);
      rows.push(""); add(L.s5.name, d.fullName, 100); add(L.s5.phone, d.phone, 40); add(L.s5.method.replace(/\s*\*.*/, ""), d.method); add(L.s5.company.replace(/\s*\(.*\)/, ""), d.company, 100); add(L.s5.email.replace(/\s*\(.*\)/, ""), d.email, 120); add(L.s5.whatsapp.replace(/\s*\(.*\)/, ""), d.whatsapp, 40);
      var s = rows.join("\n"); return s.length > 1800 ? s.slice(0, 1790) + "…" : s;
    }
    function review() {
      var L = I[lang()].wizard, d = data(), dl = document.getElementById("review-list"); dl.innerHTML = "";
      var rows = [[L.labels.services, d.services.join(lang() === "ar" ? "، " : ", "), 0], [L.labels.description, [d.projectName, d.description].filter(Boolean).join(" — "), 1], [L.s2.problem, d.businessProblem, 1], [L.s2.features, d.requiredFeatures, 1],
        [L.s3.title, [d.existingWebsite, d.domain, d.hosting, d.existingDatabase, d.integrations].filter(Boolean).join(" · "), 2], [L.labels.budget, d.budget, 3], [L.labels.timeline, [d.timeline, d.deadline].filter(Boolean).join(" — "), 3],
        [L.labels.contact, [d.fullName, d.company, d.phone, d.email, d.method].filter(Boolean).join(" · "), 4]];
      rows.forEach(function (r) {
        var div = document.createElement("div"), dt = document.createElement("dt"), dd = document.createElement("dd"), ed = document.createElement("dd"), b = document.createElement("button");
        dt.textContent = r[0]; dd.textContent = r[1] || L.s7.none; b.type = "button"; b.className = "linkbtn"; b.textContent = L.edit; b.addEventListener("click", function () { go(r[2]); }); ed.appendChild(b);
        div.appendChild(dt); div.appendChild(dd); div.appendChild(ed); dl.appendChild(div);
      });
    }
    function go(n) {
      cur = n; steps.forEach(function (s, i) { s.hidden = i !== n; });
      var L = I[lang()].wizard;
      title.textContent = L.stepTitles[n]; info.textContent = L.stepOf.replace("{a}", n + 1).replace("{b}", L.steps.length) + " — " + L.steps[n];
      prog.querySelectorAll("li").forEach(function (li, i) { li.classList.toggle("on", i <= n); });
      back.hidden = n === 0; next.hidden = n === steps.length - 1; fin.hidden = n !== steps.length - 1;
      if (n === steps.length - 1) { review(); }
      result.hidden = true; title.focus(); window.scrollTo({ top: 0, behavior: "smooth" });
    }
    document.addEventListener("cs:lang", function () { go(cur); });
    next.addEventListener("click", function () { if (validate(cur)) go(cur + 1); });
    back.addEventListener("click", function () { go(Math.max(0, cur - 1)); });
    wz.addEventListener("submit", function (e) { e.preventDefault(); if (cur < steps.length - 1) { if (validate(cur)) go(cur + 1); } });

    function showResult(kind, headKey, bodyKey) {
      var L = I[lang()].wizard; result.hidden = false; result.setAttribute("role", kind === "error" ? "alert" : "status");
      result.querySelector("h2").textContent = L[headKey]; result.querySelector("p.msg").textContent = L[bodyKey]; result.focus();
    }
    function guard() { for (var s of [0, 1, 3, 4]) { if (!validate(s)) { go(s); return false; } } return true; }
    document.getElementById("send-wa").addEventListener("click", function () {
      if (!guard()) return; go(steps.length - 1); openWa(waText(data())); showResult("ok", "waTitle2", "waNote2");
    });
    var send = document.getElementById("send-ep");
    if (!C.formEndpoint) send.hidden = true;
    send.addEventListener("click", function () {
      if (!guard()) return;
      if (wz.elements.website && wz.elements.website.value) return;           // honeypot
      if (Date.now() - started < 4000) { return; }                             // implausibly fast
      send.disabled = true; var d = data(); d.language = lang(); d.type = "project-request"; delete d.budgetValue;
      postJson(d).then(function (ok) { send.disabled = false; if (ok) showResult("ok", "successTitle", "success"); else showResult("error", "failTitle", "failText"); });
    });
    go(0);
  }
})();
